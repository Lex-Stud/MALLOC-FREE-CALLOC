// SPDX-License-Identifier: BSD-3-Clause

#include "osmem.h"
#include "block_meta.h"
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>

#define MMAP_THRESHOLD (128 * 1024)
#define ALIGN(size) (((size) + 7) & ~7)
#define BLOCK_SIZE sizeof(struct block_meta)

struct block_meta *base;

void *os_malloc(size_t size)
{
	if (size == 0)
		return NULL;

	size = ALIGN(size);

	if ((size + BLOCK_SIZE) < MMAP_THRESHOLD) {

		if (base == NULL) {
			void *temp_ptr = sbrk(MMAP_THRESHOLD);

			if (temp_ptr == (void *)-1)
				exit(-1);
			base = (struct block_meta *) temp_ptr;
			base->size = MMAP_THRESHOLD - BLOCK_SIZE;
			base->status = 0;
			base->next = NULL;
			base->prev = NULL;
		}

		if (base != NULL && base->status == 2) {
			void *temp_ptr = sbrk(MMAP_THRESHOLD);

			if (temp_ptr == (void *)-1)
				exit(-1);
			base->prev = (struct block_meta *) temp_ptr;
			base->prev->size = MMAP_THRESHOLD - BLOCK_SIZE;
			base->prev->status = 0;
			base->prev->prev = NULL;
			base->prev->next = base;
			base = base->prev;
		}

		struct block_meta *best = NULL;
		struct block_meta *ant = NULL;
		struct block_meta *aux = NULL;

		for (aux = base; aux != NULL && aux->status != 2; aux = aux->next) {
			if (aux->status == 0 && aux->size >= size && (best == NULL || ((best->size - size) > (aux->size - size))))
				best = aux;
			ant = aux;
		}

		if (best == NULL) {
			if (ant->status == 0) {
				void *temp_ptr = sbrk(size - ant->size);

				if (temp_ptr == (void *)-1)
					exit(-1);
				ant->status = 1;
				ant->size = size;
				temp_ptr = (void *) ant + BLOCK_SIZE;

				return temp_ptr;
			} else {
				void *temp_ptr = sbrk(size + BLOCK_SIZE);

				if (temp_ptr == (void *)-1)
					exit(-1);
				struct block_meta *urm = ant->next;
	
				ant->next = (struct block_meta *) temp_ptr;
				ant->next->status = 1;
				ant->next->size = size;
				ant->next->prev = ant;
				ant->next->next = urm;
				if (urm != NULL)
					urm->prev = ant->next;
				temp_ptr = temp_ptr + BLOCK_SIZE;
				return temp_ptr;
			}
		} else {
			if (best->size - size >= 8 + BLOCK_SIZE) {
				void *temp_ptr = (void *) best;
				struct block_meta *new = (struct block_meta *)(temp_ptr + BLOCK_SIZE + size);

				new->status = 0;
				best->status = 1;
				new->next = best->next;
				new->prev = best;
				best->next = new;
				if (new->next != NULL)
					new->next->prev = new;
				new->size = best->size - size - BLOCK_SIZE;
				best->size = size;
				temp_ptr = temp_ptr + BLOCK_SIZE;
				return temp_ptr;
			} else {
				void *temp_ptr = (void *) best;

				best->status = 1;
				temp_ptr = temp_ptr + BLOCK_SIZE;

				return temp_ptr;
			}
		}
	} else {
		struct block_meta *aux = base;

		if (aux != NULL)
			for (; aux->next != NULL; aux = aux->next)
			;
		void *temp_ptr = mmap(NULL, BLOCK_SIZE + size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

		if (temp_ptr == MAP_FAILED)
			exit(-1);
		if (aux != NULL) {
			aux->next = (struct block_meta *) temp_ptr;
			aux->next->status = 2;
			aux->next->size = size;
			aux->next->prev = aux;
			aux->next->next = NULL;
		} else {
			base = (struct block_meta *) temp_ptr;

			base->status = 2;
			base->size = size;
			base->prev = NULL;
			base->next = NULL;
		}
		temp_ptr = temp_ptr + BLOCK_SIZE;

		return temp_ptr;
	}
}

void os_free(void *ptr)
{
	struct block_meta *aux = base;

	if (aux == NULL)
		return;
	if ((void *) base + BLOCK_SIZE == ptr) {
		if (base->status == 2) {
			base = base->next;
			int ok = munmap((void *) aux, aux->size + BLOCK_SIZE);

			if (ok == -1)
				exit(-1);
			return;
		} else {
			base->status = 0;
		}
	} else {
		while ((void *) aux + BLOCK_SIZE != ptr)
			aux = aux->next;
		if (aux->status == 2) {
			if (aux->prev != NULL)
				aux->prev->next = aux->next;
			if (aux->next != NULL)
				aux->next->prev = aux->prev;

			int ok = munmap((void *)aux, aux->size + BLOCK_SIZE);

			if (ok == -1)
				exit(-1);
			return;
		} else {
			aux->status = 0;
		}
	}
	aux = base;
	while (aux != NULL) {
		if (aux->status == 0 && aux->next && aux->next->status == 0) {
			aux->size = aux->size + BLOCK_SIZE + aux->next->size;
			if (aux->next->next != NULL)
				aux->next->next->prev = aux;
			aux->next = aux->next->next;
			aux = base;
		}
		aux = aux->next;
	}
}

void *os_calloc(size_t nmemb, size_t size)
{
	if (size * nmemb == 0)
		return NULL;

	size = ALIGN(size * nmemb);

	if ((int)(size + BLOCK_SIZE) < getpagesize()) {

		if (base == NULL) {
			void *temp_ptr = sbrk(MMAP_THRESHOLD);

			if (temp_ptr == (void *)-1)
				exit(-1);
			base = (struct block_meta *) temp_ptr;
			base->size = MMAP_THRESHOLD - BLOCK_SIZE;
			base->status = 0;
			base->next = NULL;
			base->prev = NULL;
		}

		if (base != NULL && base->status == 2) {
			void *temp_ptr = sbrk(MMAP_THRESHOLD);

			if (temp_ptr == (void *)-1)
				exit(-1);
			base->prev = (struct block_meta *) temp_ptr;
			base->prev->size = MMAP_THRESHOLD - BLOCK_SIZE;
			base->prev->status = 0;
			base->prev->prev = NULL;
			base->prev->next = base;
			base = base->prev;
		}

		struct block_meta *best = NULL;
		struct block_meta *ant = NULL;
		struct block_meta *aux = NULL;

		for (aux = base; aux != NULL && aux->status != 2; aux = aux->next) {
			if (aux->status == 0 && aux->size >= size && (best == NULL || ((best->size - size) > (aux->size - size))))
				best = aux;
			ant = aux;
		}

		if (best == NULL) {
			if (ant->status == 0) {
				void *temp_ptr = sbrk(size - ant->size);

				if (temp_ptr == (void *)-1)
					exit(-1);
				ant->status = 1;
				ant->size = size;
				temp_ptr = (void *) ant + BLOCK_SIZE;
				memset(temp_ptr, 0, ((struct block_meta *)(temp_ptr - BLOCK_SIZE))->size);
				return temp_ptr;
			} else {
				void *temp_ptr = sbrk(size + BLOCK_SIZE);

				if (temp_ptr == (void *)-1)
					exit(-1);
				struct block_meta *urm = ant->next;

				ant->next = (struct block_meta *) temp_ptr;
				ant->next->status = 1;
				ant->next->size = size;
				ant->next->prev = ant;
				ant->next->next = urm;
				if (urm != NULL)
					urm->prev = ant->next;
				temp_ptr = temp_ptr + BLOCK_SIZE;
				memset(temp_ptr, 0, ((struct block_meta *)(temp_ptr - BLOCK_SIZE))->size);
				return temp_ptr;
			}
		} else {
			if (best->size - size >= 8 + BLOCK_SIZE) {
				void *temp_ptr = (void *) best;
				struct block_meta *new = (struct block_meta *)(temp_ptr + BLOCK_SIZE + size);

				new->status = 0;
				best->status = 1;
				new->next = best->next;
				new->prev = best;
				best->next = new;
				if (new->next != NULL)
					new->next->prev = new;
				new->size = best->size - size - BLOCK_SIZE;
				best->size = size;
				temp_ptr = temp_ptr + BLOCK_SIZE;
				memset(temp_ptr, 0, ((struct block_meta *)(temp_ptr - BLOCK_SIZE))->size);
				return temp_ptr;
			} else {
				void *temp_ptr = (void *) best;

				best->status = 1;
				temp_ptr = temp_ptr + BLOCK_SIZE;
				memset(temp_ptr, 0, ((struct block_meta *)(temp_ptr - BLOCK_SIZE))->size);
				return temp_ptr;
			}
		}
	} else {
		struct block_meta *aux = base;

		if (aux != NULL)
			for (; aux->next != NULL; aux = aux->next)
			;
		void *temp_ptr = mmap(NULL, BLOCK_SIZE + size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

		if (temp_ptr == MAP_FAILED)
			exit(-1);
		if (aux != NULL) {
			aux->next = (struct block_meta *) temp_ptr;
			aux->next->status = 2;
			aux->next->size = size;
			aux->next->prev = aux;
			aux->next->next = NULL;
		} else {
			base = (struct block_meta *) temp_ptr;
			base->status = 2;
			base->size = size;
			base->prev = NULL;
			base->next = NULL;
		}
		temp_ptr = temp_ptr + BLOCK_SIZE;
		memset(temp_ptr, 0, ((struct block_meta *)(temp_ptr - BLOCK_SIZE))->size);
		return temp_ptr;
	}
}

void *os_realloc(void *ptr, size_t size)
{
	/* TODO: Implement os_realloc */
	return NULL;
}
